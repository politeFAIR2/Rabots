﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using static System.Net.Mime.MediaTypeNames;


namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {

        private Point PreviousPoint, point;
        private Bitmap bmp;
        private Pen blackPen;
        private Graphics g;
      //  private NumericUpDown numericUpDownBrushSize;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            blackPen = new Pen(Color.Black, 4);
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();


            dialog.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif; *.png";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                //r1
                System.Drawing.Image image = System.Drawing.Image.FromFile(dialog.FileName); int width = image.Width;
                int height = image.Height; pictureBox1.Width = width; pictureBox1.Height = height;

                bmp = new Bitmap(image, width, height);
            }

            pictureBox1.Image = bmp;

            g = Graphics.FromImage(pictureBox1.Image);
        }


        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {


            PreviousPoint.X = e.X; PreviousPoint.Y = e.Y;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {

                point.X = e.X; point.Y = e.Y;
                g.DrawLine(blackPen, PreviousPoint, point);
                PreviousPoint.X = point.X; PreviousPoint.Y = point.Y;


                pictureBox1.Invalidate();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            SaveFileDialog savedialog = new SaveFileDialog();
            savedialog.Title = "Сохранить картинку как ...";
            savedialog.OverwritePrompt = true;
            savedialog.CheckPathExists = true;
            savedialog.Filter = "Bitmap File(*.bmp)|*.bmp|" + "GIF File(*.gif)|*.gif|" + "JPEG File(*.jpg)|*.jpg|" + "PNG File(*.png)|*.png";
            if (savedialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = savedialog.FileName;
                string strFilExtn = fileName.Remove(0, fileName.Length - 3);
                switch (strFilExtn)
                {

                    case "bmp":
                        bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Bmp); break;
                    case "jpg":
                        bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg); break;
                    case "gif":
                        bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Gif); break;
                    case "tif":
                        bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Tiff); break;
                    case "png":
                        bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Png); break;
                    default:
                        break;
                }

            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
        
            for (int i = 0; i < bmp.Width; i++)
                for (int j = 0; j < bmp.Height; j++)
                {
                    
                    int R = bmp.GetPixel(i, j).R;
              
                    int G = bmp.GetPixel(i, j).G;
              
                    int B = bmp.GetPixel(i, j).B;
                   
                    int Gray = (R + G + B) / 3;
     
                    Color p = Color.FromArgb(255, Gray, Gray, Gray);
                    bmp.SetPixel(i, j, p);
                }

            Refresh();
        }

        //re2
        private Color selectedColor = Color.Black;
        private int brushSize = 4;
        private int Limit(int value)
        {
            if (value < 0) return 0;
            if (value > 255) return 255;
            return value;
        }

        private void btnColorPicker_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                selectedColor = colorDialog.Color;
                blackPen = new Pen(selectedColor, brushSize);
            }
        }

        private void numericUpDownBrushSize_ValueChanged(object sender, EventArgs e)
        {
            brushSize = (int)numericUpDownBrushSize.Value;
            blackPen = new Pen(selectedColor, brushSize);
        }
        private void AddRandomPoints()
        {
            Random rand = new Random();
            for (int i = 0; i < 1000; i++)
            {
                int x = rand.Next(bmp.Width);
                int y = rand.Next(bmp.Height);
                Color randomColor = Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256));
                bmp.SetPixel(x, y, randomColor);
            }
            Refresh();
        }
        private void ConvertToGrayscale(int threshold)
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;
                    if (gray < threshold)
                        bmp.SetPixel(i, j, Color.Black);
                    else
                        bmp.SetPixel(i, j, Color.White);
                }
            }
            Refresh();
        }
        private void KeepColorChannel(string channel)
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    Color newColor;

                    if (channel == "R")
                    {
                        newColor = Color.FromArgb(pixel.R, 0, 0);
                    }
                    else if (channel == "G")
                    {
                        newColor = Color.FromArgb(0, pixel.G, 0);
                    }
                    else if (channel == "B")
                    {
                        newColor = Color.FromArgb(0, 0, pixel.B);
                    }
                    else
                    {
                        newColor = pixel; 
                    }

                    bmp.SetPixel(i, j, newColor);
                }
            }
            Refresh();
        }

        private void DrawCircle(int radius)
        {
            int centerX = bmp.Width / 2;
            int centerY = bmp.Height / 2;

            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    if (Math.Sqrt(Math.Pow(i - centerX, 2) + Math.Pow(j - centerY, 2)) > radius)
                    {
                        Color pixel = bmp.GetPixel(i, j);
                        int gray = (pixel.R + pixel.G + pixel.B) / 3;
                        bmp.SetPixel(i, j, Color.FromArgb(gray, gray, gray));
                    }
                }
            }
            Refresh();
        }
        private void DrawTriangle(Point p1, Point p2, Point p3)
        {
           
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                   
                    Color pixel = bmp.GetPixel(i, j);
                    if (!IsPointInTriangle(new Point(i, j), p1, p2, p3))
                    {
                        bmp.SetPixel(i, j, Color.FromArgb(0, 0, pixel.B));
                    }
                    else
                    {
                        int gray = (pixel.R + pixel.G + pixel.B) / 3;
                        bmp.SetPixel(i, j, Color.FromArgb(gray, gray, gray));
                    }
                }
            }
            Refresh();
        }

        
        private bool IsPointInTriangle(Point pt, Point p1, Point p2, Point p3)
        {
            return false;
        }
        private void DrawDiamond(int width, int height)
        {
            int centerX = bmp.Width / 2;
            int centerY = bmp.Height / 2;

            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    if (Math.Abs(i - centerX) + Math.Abs(j - centerY) > width / 2)
                    {
                        Color pixel = bmp.GetPixel(i, j);
                        int gray = (pixel.R + pixel.G + pixel.B) / 3;
                        bmp.SetPixel(i, j, Color.FromArgb(0, gray, 0));
                    }
                }
            }
            Refresh();
        }
        private void ConvertEvenRowsToGray()
        {
            for (int j = 0; j < bmp.Height; j += 2)
            {
                for (int i = 0; i < bmp.Width; i++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;
                    bmp.SetPixel(i, j, Color.FromArgb(gray, gray, gray));
                }
            }
            Refresh();
        }
        private void ConvertOddColumnsToGray()
        {
            for (int i = 1; i < bmp.Width; i += 2)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;
                    bmp.SetPixel(i, j, Color.FromArgb(gray, gray, gray));
                }
            }
            Refresh();
        }
        private void SplitImageIntoFourParts()
        {
            int halfWidth = bmp.Width / 2;
            int halfHeight = bmp.Height / 2;

            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    if (i < halfWidth && j < halfHeight) 
                        bmp.SetPixel(i, j, Color.FromArgb(pixel.R, 0, 0));
                    else if (i >= halfWidth && j < halfHeight)
                        bmp.SetPixel(i, j, Color.FromArgb(0, pixel.G, 0));
                    else if (i < halfWidth && j >= halfHeight) 
                        bmp.SetPixel(i, j, Color.FromArgb(0, 0, pixel.B));
                    else 
                        bmp.SetPixel(i, j, Color.FromArgb((pixel.R + pixel.G + pixel.B) / 3, (pixel.R + pixel.G + pixel.B) / 3, (pixel.R + pixel.G + pixel.B) / 3));
                }
            }
            Refresh();
        }

        private void ReplaceBlueWithRed()
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    if (pixel.B > pixel.R && pixel.B > pixel.G) 
                    {
                        bmp.SetPixel(i, j, Color.FromArgb(pixel.R, pixel.G, 0));
                    }
                }
            }
            Refresh();
        }
        private void InvertToNegative()
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    bmp.SetPixel(i, j, Color.FromArgb(255 - pixel.R, 255 - pixel.G, 255 - pixel.B));
                }
            }
            Refresh();
        }


        private void AdjustBrightness(int value)
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int r = Limit(pixel.R + value);
                    int g = Limit(pixel.G + value);
                    int b = Limit(pixel.B + value);
                    bmp.SetPixel(i, j, Color.FromArgb(r, g, b));
                }
            }
            Refresh();
        }
        private void ConvertToBlackAndWhiteWithThreshold(int threshold, string channel)
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int value;

                    if (channel == "R")
                    {
                        value = pixel.R;
                    }
                    else if (channel == "G")
                    {
                        value = pixel.G;
                    }
                    else if (channel == "B")
                    {
                        value = pixel.B;
                    }
                    else
                    {
                        value = 0;
                    }

                    if (value < threshold)
                        bmp.SetPixel(i, j, Color.Black);
                    else
                        bmp.SetPixel(i, j, Color.White);
                }
            }
            Refresh();
        }

        private void MosaicEffect(int blockSize)
        {
            for (int i = 0; i < bmp.Width; i += blockSize)
            {
                for (int j = 0; j < bmp.Height; j += blockSize)
                {
                    Color avgColor = GetAverageColor(i, j, blockSize);
                    for (int x = 0; x < blockSize && (i + x) < bmp.Width; x++)
                    {
                        for (int y = 0; y < blockSize && (j + y) < bmp.Height; y++)
                        {
                            bmp.SetPixel(i + x, j + y, avgColor);
                        }
                    }
                }
            }
            Refresh();
        }

        private Color GetAverageColor(int startX, int startY, int blockSize)
        {
            int r = 0, g = 0, b = 0, count = 0;
            for (int x = 0; x < blockSize && (startX + x) < bmp.Width; x++)
            {
                for (int y = 0; y < blockSize && (startY + y) < bmp.Height; y++)
                {
                    Color pixel = bmp.GetPixel(startX + x, startY + y);
                    r += pixel.R;
                    g += pixel.G;
                    b += pixel.B;
                    count++;
                }
            }
            return Color.FromArgb(r / count, g / count, b / count);
        }
        private void SplitChannels()
        {
            int halfWidth = bmp.Width / 2;
            int halfHeight = bmp.Height / 2;

            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    if (i < halfWidth && j < halfHeight) 
                        bmp.SetPixel(i, j, Color.FromArgb(pixel.R, 0, 0));
                    else if (i >= halfWidth && j < halfHeight) 
                        bmp.SetPixel(i, j, Color.FromArgb(0, pixel.G, 0));
                    else if (i < halfWidth && j >= halfHeight) 
                        bmp.SetPixel(i, j, Color.FromArgb(0, 0, pixel.B));
                    else 
                        bmp.SetPixel(i, j, Color.FromArgb((pixel.R + pixel.G + pixel.B) / 3, (pixel.R + pixel.G + pixel.B) / 3, (pixel.R + pixel.G + pixel.B) / 3));
                }
            }
            Refresh();
        }
        private void ChangeRedChannel(int value)
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int newR = Limit(pixel.R + value);
                    bmp.SetPixel(i, j, Color.FromArgb(newR, pixel.G, pixel.B));
                }
            }
            Refresh();
        }
        private void ZeroOutColorChannel(string channel)
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    Color newColor;

                    if (channel == "R")
                    {
                        newColor = Color.FromArgb(0, pixel.G, pixel.B);
                    }
                    else if (channel == "G")
                    {
                        newColor = Color.FromArgb(pixel.R, 0, pixel.B);
                    }
                    else if (channel == "B")
                    {
                        newColor = Color.FromArgb(pixel.R, pixel.G, 0);
                    }
                    else
                    {
                        newColor = pixel; 
                    }

                    bmp.SetPixel(i, j, newColor);
                }
            }
            Refresh();
        }

        private void ConvertRectangleToGray(int startX, int startY, int width, int height)
        {
            for (int i = startX; i < startX + width && i < bmp.Width; i++)
            {
                for (int j = startY; j < startY + height && j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;
                    bmp.SetPixel(i, j, Color.FromArgb(gray, gray, gray));
                }
            }
            Refresh();
        }
        private void ConvertGrayToColor()
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixel = bmp.GetPixel(i, j);
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;

                    Color newColor = gray < 128 ? Color.Red : Color.Blue; 
                    bmp.SetPixel(i, j, newColor);
                }
            }
            Refresh();
        }

    }
}

        